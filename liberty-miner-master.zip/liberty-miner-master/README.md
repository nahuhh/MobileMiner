# Liberty Miner GUI™

It's a begginer friendly version of LP-XMRig, with a graphical user inteface where you can with a few clicks start mining the most profitable coin for your hardware. Also see your stats and the pool stats. Also it auto-update to the lastest LP-XMRig version.

Take a look at the comparasion bettwen this miner and others [here](https://help.liberty-pool.com/downloads/). 

## Features
#### - Get automatic updates of XMRig
#### -  All in one statistics panel included into the app
#### -  RAM usage and CPU temperatures statistics
#### -  Personalize your miner config in the fancy config interface 

### Reminder: Change the default address to yours in the settings!
