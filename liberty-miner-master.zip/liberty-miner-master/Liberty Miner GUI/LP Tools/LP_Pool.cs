﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

internal class LP_Pool
    {
    public static string GetNextPaymentDate()
    {
        string apiresult = LP_Tools.DownloadString(LP_Data.PoolApiPaymentsURL);
        //Adapting API to LP GUI
        StringBuilder stringBuilder = new StringBuilder(apiresult);
        stringBuilder.Replace("ts", "Time");
        stringBuilder.Replace("amount", "Amount");
        string json = stringBuilder.ToString();
        // Deserializing json data to WalletPayment
        JavaScriptSerializer js = new JavaScriptSerializer();
        List<WalletPayment> paymentObjects = js.Deserialize<List<WalletPayment>>(json);
        //preparing the output...
        string result = LP_Tools.JavaTimeStampToDateTime(paymentObjects[0].Time).AddHours(24).ToString();
        return result;
    }
    static public async Task<PoolData> FetchPoolDataAsync()
    {
        PoolData result = new PoolData();
        //
        string poolresult;
        using (var client = new WebClient())
        {
            poolresult = await client.DownloadStringTaskAsync(LP_Data.PoolApiURL);
        }
        dynamic pool = JObject.Parse(poolresult);
        //
        string xmrresult;
        using (var client = new WebClient())
        {
            xmrresult = await client.DownloadStringTaskAsync(LP_Data.XMRpriceApiURL);
        }
        dynamic xmr = JObject.Parse(xmrresult);
        //
        string WorldXMRresult;
        using (var client = new WebClient())
        {
            WorldXMRresult = await client.DownloadStringTaskAsync(LP_Data.XMRhashrateApiURL);
        }
        dynamic WorldXMRHash = JObject.Parse(WorldXMRresult);
        dynamic p = pool.pool_statistics;
        //
        result.xmrPrice = xmr.EUR + "€  " + xmr.USD + "$ ";
        result.TotalPayments = p.totalPayments;
        result.BlocksFound = p.totalAltBlocksFound + p.totalBlocksFound;
        result.TotalMinersPaid = p.totalMinersPaid;
        //
        string worldHash = WorldXMRHash.hashrate;
        result.WorldXMRHashrate = LP_Tools.ConvertRawHashToCorrespondentHash(worldHash);
        string totalHashes = p.totalHashes;
        result.TotalPoolHashrate = LP_Tools.ConvertRawGigaHashes(totalHashes);
        string poolHashes = p.hashRate;
        result.PoolHashrate = LP_Tools.ConvertRawHashToCorrespondentHash(poolHashes);
        //
        return result;
    }

}
