﻿
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

public class LP_Wallet
    {
    private string Address;
    #region GET
    public string GetAddress()
    {
        return Address;
    }
    public string GetRawStats()
    {
        return "https://api.liberty-pool.com/miner/" + Address + "/stats";
    }
    string GetRawPaymentStats()
    {
        return "https://api.liberty-pool.com/miner/" + Address + "/payments";
    }
    async public Task<WalletData> GetData()
    {
        WalletData result = new WalletData();
        string apiresult;
        using (var client = new WebClient())
        {
            apiresult = await client.DownloadStringTaskAsync(GetRawStats());
        }
        dynamic w = JObject.Parse(apiresult);
        result.Paid = w.amtPaid / Math.Pow(10, 12);
        result.Pending = w.amtDue / Math.Pow(10, 12);
        result.Hashes = LP_Tools.ConvertRawHashToCorrespondentHash(Convert.ToString(w.hash));
        return result;
    }
    public List<WalletPayment> GetPayments()
    {
        string apiresult = LP_Tools.DownloadString(GetRawPaymentStats());
        // If there's no payments:
        if (apiresult == "[]")
        {
            List<WalletPayment> payments = new List<WalletPayment>();
            payments.Add(new WalletPayment());
            payments[0].Amount = "Nein";
            return payments;
        }
        //Adapting API to LP GUI
        StringBuilder stringBuilder = new StringBuilder(apiresult);
        stringBuilder.Replace("ts", "Time");
        stringBuilder.Replace("amount", "Amount");
        string json = stringBuilder.ToString();
        // Deserializing json data to WalletPayment
        JavaScriptSerializer js = new JavaScriptSerializer();
        List<WalletPayment> paymentObjects = js.Deserialize<List<WalletPayment>>(json);
        //preparing the output...
        List<WalletPayment> result = new List<WalletPayment>();
        foreach (WalletPayment w in paymentObjects)
        {
            w.Time = LP_Tools.TimeStampToDateTime(w.Time).ToString();
            w.Amount = (float.Parse(w.Amount) / Math.Pow(10, 12)).ToString() + " XMR";
            result.Add(w);
        }
        return result;
    }
    #endregion
    #region SET
    public LP_Wallet(string address)
    {
        SetAdress(address);
    }

    public void SetAdress(string address) 
    {
        Address = address;
    }
    #endregion
}