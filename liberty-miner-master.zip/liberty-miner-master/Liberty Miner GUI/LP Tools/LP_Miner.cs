﻿using LibertyMinerGUI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class LP_Miner
{
    //public static bool ShouldRunAsAdmin = false;
    public Stopwatch xmrigWatch = new Stopwatch();
    public string xmrigOutput = "XMRIG is not running...";
    public Process process;
    public void Kill()
    {
        if (Running())
            process.Kill();
        // Configures the LP Singleton
        xmrigWatch.Reset();
        xmrigOutput = "XMRIG has exited...";
    }
    public void Run()
    {
        // Check if miner/config exists
        if (!LP_Tools.ConfigExists())
            LP_Tools.ApplyConfig();
        if (!LP_Tools.MinerExists())
        {
            Form1 form1 = new Form1();
            form1.Show();
            LP_Data.form1.Invoke(LP_Data.form1._Close);
        }
        // Start the child process.
        Process p = new Process();
        // set up output redirection
        p.StartInfo.FileName = LP_Data.xmrigPath;
        p.StartInfo.UseShellExecute = false;
        p.StartInfo.CreateNoWindow = true;
        // Ask for admin requests
        //int decision = 2;
        ////if (!LP_Data.APP_DATA.AskIfMinerShouldRunAsAdmin)
        ////{
        //LP_Message message = new LP_Message("Do you want to run the miner as admin for maximum performance?",
        //    "Yes", null, "No", ref decision, ref LP_Data.APP_DATA.AskIfMinerShouldRunAsAdmin);
        //message.ShowDialog();
        //message.Close();
        //LP_Tools.SaveAppData(LP_Data.APP_DATA);
        //if (decision == 1)
        //    if (ShouldRunAsAdmin) p.StartInfo.Verb = "runas";
        ////}
        //Configures the miner to output the logs in the terminal
        p.StartInfo.RedirectStandardOutput = true;
        p.OutputDataReceived += new DataReceivedEventHandler(XMRigOutput_Event);
        p.Start();
        process = p;
        // Configures the LP Singleton
        xmrigWatch.Start();
        // Output
        process.BeginOutputReadLine();
    }
    public bool Running()
    {
        if (LP_Tools.IsProcessRunning(process))
        {
            return true;
        }
        else if (LP_Tools.IsProcessRunning("xmrig"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    #region Console Output
    private int lineCount = 0;
    private StringBuilder output = new StringBuilder();
    private void XMRigOutput_Event(object sender, DataReceivedEventArgs e)
    {
        if (!String.IsNullOrEmpty(e.Data))
        {
            lineCount++;
            output.Append("\n[" + lineCount + "]: " + e.Data);
        }
        xmrigOutput = output.ToString();
        Console.WriteLine(output.ToString());
    }
    #endregion
}
