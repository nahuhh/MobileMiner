﻿using LibertyMinerGUI.Properties;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

internal class LP_Tools
{
    #region Maths
    static public string ConvertRawGigaHashes(string Hashes)
    {
        Hashes = Hashes.Split('.')[0];
        if (Hashes == null)
            return "No hashes yet...";
        double hash = Math.Round(float.Parse(Hashes), 1);
        double numlength = Math.Floor(Math.Log10(hash) + 1);
        hash = hash / 1000000000;
        string MinerHashrate = "Hashes: " + Math.Round(hash, 1) + " GHs";
        return MinerHashrate;
    }
    static public string ConvertRawHashToCorrespondentHash(string Hashes)
    {
        if (Hashes == null)
            return "No hashrates yet...";
        Hashes = Hashes.Split('.')[0];
        double hash = Math.Round(float.Parse(Hashes), 1);
        double numlength = Math.Floor(Math.Log10(hash) + 1);
        string MinerHashrate = "";
        if (numlength >= 10)
        {
            hash = hash / 1000000000;

            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " GHS";
        }
        else if (numlength >= 7)
        {
            hash = hash / 1000000;

            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " MHS";
        }
        else if (numlength == 6)
        {
            hash = hash / 1000;
            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " KHS";
        }
        else if (numlength == 5)
        {
            hash = hash / 1000;
            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " KHS";
        }
        else if (numlength == 4)
        {
            hash = hash / 1000;
            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " KHS";
        }
        else if (numlength < 3)
        {
            MinerHashrate = "Hashrate: " + Math.Round(hash, 1) + " HS";
        }
        else
        {
            MinerHashrate = "No hashrates yet...";
        }
        return MinerHashrate;
    }
    #endregion
    public static string DownloadString(string address)
    {
        ServicePointManager.Expect100Continue = true;
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        WebClient client = new WebClient();
        Uri uri = new Uri(address);
        string reply = client.DownloadString(uri);
        return reply;
    }
    public static void Print(RichTextBox box, string message)
    {
        if (box.Text == "")
        {
            box.Text += message;
        }
        else
        {
            box.Text += Environment.NewLine + message;
        }
    }
    #region Get Memory Data
    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    static extern bool GetPhysicallyInstalledSystemMemory(out long TotalMemoryInKilobytes);
    static public float GetMinerMemoryUsageMB()
    {
        Process[] localByName = Process.GetProcessesByName("xmrig");
        long x = 0;
        float y = 0;
        foreach (Process p in localByName)
        {
            long memoryUse = (p.PagedMemorySize64);
            x = memoryUse;
            y = x / 100000;
            y = y / 10;
        }
        return y;
    }
    static public float GetLPGUIMemoryUsage()
    {
        long t = Process.GetCurrentProcess().PrivateMemorySize64;
        return (float)t / 1024;
    }
    static public float GetPCMemory()
    {
        long memKb;
        GetPhysicallyInstalledSystemMemory(out memKb);
        return (float)memKb;
    }
    static public string TotalMemoryUsagePercentage()
    {
        float usage = GetLPGUIMemoryUsage() + GetMinerMemoryUsageMB();
        float y = (usage * 100) / GetPCMemory();
        return Math.Round(y, 2) + " %";
    }
    #endregion
    #region PC-Level & Low-Level
    static public async Task<bool> InternetConnectionAvailableAsync()
    {
        Ping myPing = new Ping();
        try
        {
            var pingReply = await myPing.SendPingAsync("google.com", 3000, new byte[32], new PingOptions(64, true));
            if (pingReply.Status == IPStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            return false;
        }
    }
    static public string GetCPUtemp()
    {
        Double temperature = 0;
        String instanceName = "";
        // Query the MSAcpi_ThermalZoneTemperature API
        ManagementObjectSearcher searcher = new ManagementObjectSearcher(@"root\WMI", "SELECT * FROM MSAcpi_ThermalZoneTemperature");

        foreach (ManagementObject obj in searcher.Get())
        {
            temperature = Convert.ToDouble(obj["CurrentTemperature"].ToString());
            // Convert the value to celsius degrees
            temperature = (temperature - 2732) / 10.0;
            instanceName = obj["InstanceName"].ToString();
        }
        return temperature.ToString() + " º";
    }
    public static bool IsProcessRunning(string name)
    {
        Process[] pname = Process.GetProcessesByName(name);
        if (pname.Length > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    static public bool IsProcessRunning(Process process)
    {
        if (process == null)
            return false;
        try
        {
            Process.GetProcessById(process.Id);
        }
        catch
        {
            return false;
        }
        return true;
    }
    public static void CloseProcess(string processn)
    {
        Process[] processes = Process.GetProcessesByName(processn);
        foreach (Process process in processes)
        {
            process.Kill();
            process.WaitForExit();
            process.Dispose();
        }
    }
    public static DateTime TimeStampToDateTime(string TimeStamp)
    {
        long l1 = (long)Convert.ToDouble(TimeStamp);
        return new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddSeconds(l1).ToUniversalTime();
    }
    public static DateTime JavaTimeStampToDateTime(string TimeStamp)
    {
        long l1 = (long)Convert.ToDouble(TimeStamp);
        return new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(l1).ToUniversalTime();
    }
    #endregion
    #region Miner
    public static async Task<string> UpdatePaymentThreshold(string PaymentAmount, string Address)
    {
        var values = new Dictionary<string, string>
            {
                { "username",  Address},
                { "threshold", PaymentAmount}
            };
        var content = new FormUrlEncodedContent(values);
        var response = await LP_Data.client.PostAsync(LP_Data.ThresholdApiPaymentsURL, content);
        var responseString = await response.Content.ReadAsStringAsync();
        return responseString;
    }
    static public async Task<bool> IsWalletNewAsync(LP_Wallet wallet)
    {
        string apiresult;
        using (var client = new WebClient())
        {
            apiresult = await client.DownloadStringTaskAsync(wallet.GetRawStats());
        }
        dynamic w = JObject.Parse(apiresult);
        string lastHash = w.lastHash;
        string validShares = w.validShares;
        string amtPaid = w.amtPaid;
        string amtDue = w.amtDue;
        if (amtDue == "0" && amtPaid == "0" && lastHash == "null"
            && validShares == "0" && !apiresult.Contains("totalHashes"))
            return true;
        else return false;
    }
    static public bool DoesAnyWalletExist()
    {

        string foundWallet = LP_Data.CONFIG_DATA.Wallet;
        // SET is the default value of the wallet address
        if (foundWallet != "SET" && IsWalletValid(foundWallet))
        {
            //Initialize wallet and miner Instances to be ready for mining and stats display
            LP_Data.wallet = new LP_Wallet(foundWallet);
            LP_Data.miner = new LP_Miner();
            //
            return true;
        }
        else
        {
            return false;
        }
    }
    static public bool IsWalletValid(string address)
    {
        if (address.Length == 95)
        {
            if (address[0] == '4' || address[0] == '8'
            || Enumerable.Range(0, 9).Contains(address[1])
            || address[1] == 'A' || address[1] == 'B'
            )
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        else
        {
            return false;
        }
    }
    static public bool MinerExists()
    {
        string miner = LP_Data.xmrigPath;
        string winsys = Path.Combine(Application.StartupPath, "WinRing0x64.sys");
        if (File.Exists(miner) && File.Exists(winsys))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    static public bool ConfigExists()
    {
        string config = LP_Data.configPath;
        if (File.Exists(config))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    static public void ApplyConfig()
    {
        ConfigData s = LP_Data.CONFIG_DATA;
        if (File.Exists(LP_Data.configPath))
        {
            string config = File.ReadAllText(LP_Data.configPath);
            dynamic Result = JsonConvert.DeserializeObject(config);
            ChangeConfig("pools", "pass", s.Worker + LP_Data.coins[s.Coin], config);
            ChangeConfig("pools", "url", LP_Data.cpuPorts[s.Cpu], config);
            ChangeConfig("pools", "user", s.Wallet, config);
            //
            if (s.Coin == 3)
            {
                ChangeConfig("pools", "tls", "true", config);
            }
            else
            {
                ChangeConfig("pools", "tls", "false", config);
            }
        }
        else
        {
            //
            string config = Resources.config1;
            StringBuilder stringBuilder = new StringBuilder(config);
            stringBuilder.Replace("poolminingport", LP_Data.cpuPorts[s.Cpu]);
            stringBuilder.Replace("YOUR_WALLET_ADDRESS", s.Wallet);
            stringBuilder.Replace("WORKER_NAME_HERE", s.Worker + LP_Data.coins[s.Coin]);
            if (s.Coin == 3)
            {
                stringBuilder.Replace("tlsconfiguration", "true");
            }
            else
            {
                stringBuilder.Replace("tlsconfiguration", "false");
            }
            File.WriteAllText(LP_Data.configPath, stringBuilder.ToString());
        }
        if (s.RunOnStartUp == true)
        {
            Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            key.SetValue("LP Miner GUI", Application.ExecutablePath);
        }
        else
        {
            Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            key.DeleteValue("LP Miner GUI", false);
        }
    }
    static void ChangeConfig(string header, string subheader, string value, string config)
    {
        dynamic jsonObj = Newtonsoft.Json.JsonConvert.DeserializeObject(config);
        jsonObj[header][0][subheader] = value;
        string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(LP_Data.configPath, output);
    }
    static public void SaveWallet(string address)
    {
        LP_Data.CONFIG_DATA.Wallet = address;
        SaveConfigData(LP_Data.CONFIG_DATA);
        //Initialize wallet and miner Instances to be ready for mining and stats display
        LP_Data.wallet = new LP_Wallet(address);
        LP_Data.miner = new LP_Miner();
    }
    static public void SaveConfigData(ConfigData config)
    {
        ApplyConfig();
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.StartupPath + "/config.dat");
        bf.Serialize(file, config);
        file.Close();
    }
    static public void SaveAppData(AppData data)
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.StartupPath + "/app.dat");
        bf.Serialize(file, data);
        file.Close();
    }
    #endregion
    #region Data Saving/Loading
    public static AppData LoadAppData()
    {
        string loadFile = Application.StartupPath + "/app.dat";
        if (File.Exists(loadFile))
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(loadFile, FileMode.Open);
            AppData data = (AppData)bf.Deserialize(file);
            file.Close();
            return data;
        }
        else
            return new AppData(LP_Data.LP_VERSION,"");
    }
    public static ConfigData LoadConfigData()
    {
        string loadFile = Application.StartupPath + "/config.dat";
        if (File.Exists(loadFile))
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(loadFile, FileMode.Open);
            ConfigData data = (ConfigData)bf.Deserialize(file);
            file.Close();
            return data;
        }
        else
            return new ConfigData("SET", "worker", 1,1,false,false);
    }
    #endregion

}