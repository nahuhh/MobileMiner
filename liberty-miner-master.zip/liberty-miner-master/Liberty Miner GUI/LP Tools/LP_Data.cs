﻿using LibertyMinerGUI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Windows.Forms;

public class LP_Data
{
    #region Variables
    // Default settings:
    public const string LP_VERSION = "1.3";
    public static AppData APP_DATA = LP_Tools.LoadAppData();
    public static ConfigData CONFIG_DATA = LP_Tools.LoadConfigData();
    // UPDATER'S LINKS
    public static string xmrigDownloadURL = "https://pastebin.com/raw/qj1A6wx7";
    public static string LP_DownloadURL = "https://pastebin.com/raw/7Ad9pUMU";
    public static string LP_VersionURL = "https://pastebin.com/raw/1kupkxN3";
    // APIs &
    public static HttpClient client = new HttpClient();
    public static LP_Miner miner;
    public static LP_Wallet wallet;
    public static string PoolApiURL = "https://api.liberty-pool.com/pool/stats";
    public static string PoolApiPaymentsURL = "https://api.liberty-pool.com/pool/payments?page=";
    public static string ThresholdApiPaymentsURL = "https://api.liberty-pool.com/user/updateThreshold/";
    public static string AnnouncementsApiURL = "https://pastebin.com/raw/bRj2zfxf";
    public static string XMRpriceApiURL = "https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=BTC,USD,EUR";
    public static string XMRhashrateApiURL = "https://localmonero.co/blocks/api/get_stats";
    public static string xmrigPath = Path.Combine(Application.StartupPath, "xmrig.exe");
    public static string configPath = Path.Combine(Application.StartupPath, "config.json");
    public static List<String> cpuPorts = new List<String>()
        {"mine.liberty-pool.com:3333",
         "mine.liberty-pool.com:5555",
         "mine.liberty-pool.com:7777",
         "mine.liberty-pool.com:9000"
        };
    public static List<String> coins = new List<String>()
        {String.Empty,
         String.Empty,
         "~rx/arq",
         "~cn/gpu",
         "~astrobwt",
         "~ethash",
         "~cn/rwz",
         "~cn-pico/trtl",
         "~cn/r",
         "~cn/half",
         "~kawpow",
         "~cn/gpu",
         "~cn/r",
         "~argon2/chukwav2",
         "~c29b",
         "~rx/wow",
         "~cn/gpu",
         "~cn-heavy/xhv",
         "~panthera",
         "~rx/0",
         "~c29v",
         "~c29s",
        };
    public static WalletData walletData;
    // LP's Singleton
    public static frmWallet frmwallet;
    public static Form1 form1;
    #endregion
}
public class Graph
{
    List<string> Timestamps;
    List<string> Hashes;
}
public class WalletData
{
    public string Hashes;
    public string Pending;
    public string Paid;
}
public class WalletPayment
{
    public string Time { get; set; }
    public string Amount { get; set; }
}
public class PoolData
{
    public string PoolHashrate;
    public string WorldXMRHashrate;
    public string xmrPrice;
    public int TotalPayments;
    public int BlocksFound;
    public string TotalMinersPaid;
    public string TotalPoolHashrate;
}
public interface Data { }
[Serializable]
public class AppData : Data
{
    public AppData(string lp_version, string xmrig_download)
    {
        LP_Version = lp_version;
        XMRIG_DownloadUrl = xmrig_download;
    }
    public string LP_Version;
    public string XMRIG_DownloadUrl;
    //public bool AskIfMinerShouldRunAsAdmin;
}
[Serializable]
public class ConfigData : Data
{
    public ConfigData(string wallet, string worker, int cpu, int coin, bool startup, bool battery)
    {
        Wallet = wallet;
        Worker = worker;
        Cpu = cpu;
        Coin = coin;
        RunOnStartUp = startup;
        PauseOnBattery = battery;
    }
    public string Wallet;
    public string Worker;
    public int Cpu;
    public int Coin;
    public bool RunOnStartUp;
    public bool PauseOnBattery;
}
