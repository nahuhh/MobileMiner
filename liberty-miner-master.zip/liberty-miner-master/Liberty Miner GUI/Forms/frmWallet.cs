﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Collections.Specialized;
using System.Net;
using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;

namespace LibertyMinerGUI
{
    public partial class frmWallet : Form
    {
        LP_Wallet Wallet = LP_Data.wallet;
        LP_Miner Miner = LP_Data.miner;
        public frmWallet()
        {
            InitializeComponent();
            Initialize_UI();
            LoadPayments();
            LoadData();
            InitTimer();
        }
        #region UI
        void Initialize_UI()
        {
            consoleControl1.InternalRichTextBox.ForeColor = Color.Lime;
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            OpenPanel(Stats_Panel);
            LP_Data.frmwallet = this;
        }
        void OpenPanel(Panel panel)
        {
            List<Panel> panels = new List<Panel>() { ConsolePanel, Stats_Panel, PaymentsPanel, GraphPanel };
            foreach (Panel p in panels)
            {
                if (p.Equals(panel))
                {
                    p.Visible = true;
                }
                else
                {
                    p.Visible = false;
                }
            }
        }
        #region Payments
        void LoadPayments()
        {
            RichTextBox box = payments_displayconsole.InternalRichTextBox;
            box.Text = "Loading...";
            List<WalletPayment> payments = Wallet.GetPayments();
            if (payments[0].Amount == "Nein")
            {
                box.Clear();
                LP_Tools.Print(box, "No payments yet 😭 ");
                LP_Tools.Print(box, "If you wanna know when are going to be the next payments, you can go to the Pool Section and you can check it there 😀 ");
            }
            else
            {
                box.Clear();
                foreach (WalletPayment payment in payments)
                {
                    LP_Tools.Print(box, payment.Time + ": " + payment.Amount);
                    LP_Tools.Print(box, "-------------------------------------------------");
                }
            }
        }
        private void payments_refresh_btn_Click(object sender, EventArgs e)
        {
            LoadPayments();
        }
        // This is func is done in order to prevent the console reseting bug
        private void consoleControl1_Enter(object sender, EventArgs e)
        {
            ActiveControl = ConsolePanel;
        }
        #endregion
        #endregion
        #region Data Syncing/Loading
        void LoadData()
        {
            CopyWalletButton.Text = "Copy:" + Wallet.GetAddress();
            if (Stats_Panel.Visible) LoadStatsAsync();
            if (ConsolePanel.Visible) LoadConsole();
            //
            if (Miner.Running()) RunCloseButton.Image = Properties.Resources.stop;
            else RunCloseButton.Image = Properties.Resources.play;
        }
        public void LoadConsole()
        {
            consoleControl1.InternalRichTextBox.Text = Miner.xmrigOutput;
        }
        async Task LoadStatsAsync()
        {
            if (await LP_Tools.InternetConnectionAvailableAsync())
            {
                WalletData walletData = await Wallet.GetData();
                //
                if (walletData != null)
                {
                    HashLbl.Text = walletData.Hashes;
                    PaidLbl.Text = walletData.Paid;
                    PendingLbl.Text = walletData.Pending;
                }
            }
            else
            {
                string error = "Trying to connect to the internet...";
                HashLbl.Text = error;
                PaidLbl.Text = error;
                PendingLbl.Text = error;
            }
            RAMlbl.Text = LP_Tools.TotalMemoryUsagePercentage();
            CPULbl.Text = LP_Tools.GetCPUtemp();
            //
            string elapsedHours = Miner.xmrigWatch.Elapsed.Duration().Hours.ToString();
            string elapsedMins = Miner.xmrigWatch.Elapsed.Duration().Minutes.ToString();
            string elapsedSecs = Miner.xmrigWatch.Elapsed.Duration().Seconds.ToString();
            string elapsedTime = elapsedHours + ":" + elapsedMins + ":" + elapsedSecs;
            if (Miner.Running()) XMRIG_Duration_Lbl.Text = elapsedTime;
        }
        #endregion
        #region BACKGROUND WORKER
        private Timer timer1;
        public void InitTimer()
        {
            timer1 = new Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Interval = 1000; // in miliseconds
            timer1.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadData();
        }
        #endregion
        #region Buttons
        private void CopyWalletButton_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(Wallet.GetAddress());
        }
        private void RunClose_Click(object sender, EventArgs e)
        {
            // Resources:
            Image stopIco = Properties.Resources.stop;
            Image playIco = Properties.Resources.play;
            //
            if (Miner.Running())
            {
                Miner.Kill();
                RunCloseButton.Image = stopIco;
            }
            else
            {
                Miner.Run();
                RunCloseButton.Image = playIco;
                OpenPanel(ConsolePanel);
            }
            //RunCloseMiner();
        }
        private void StatsButton_Click(object sender, EventArgs e)
        {
            OpenPanel(Stats_Panel);
        }
        private void ConsoleButton_Click(object sender, EventArgs e)
        {
            OpenPanel(ConsolePanel);
        }
        private void GraphButton_Click(object sender, EventArgs e)
        {
            OpenPanel(GraphPanel);
        }
        private void PaymentsButton_Click(object sender, EventArgs e)
        {
            OpenPanel(PaymentsPanel);
        }
        private void PaymentButton_Click(object sender, EventArgs e)
        {
            OpenPanel(PaymentsPanel);
        }
        private async void batteryBtn_Click(object sender, EventArgs e)
        {
             string response = await LP_Tools.UpdatePaymentThreshold(thresholdAmountTxt.Text, Wallet.GetAddress());
            LP_Tools.Print(payments_displayconsole.InternalRichTextBox,response);
        }
        private async void button2_Click(object sender, EventArgs e)
        {
            string response = await LP_Tools.UpdatePaymentThreshold(thresholdAmountTxt.Text, Wallet.GetAddress());
            LP_Tools.Print(payments_displayconsole.InternalRichTextBox, response);
        }
        #endregion
    }
}
