﻿namespace LibertyMinerGUI
{
    partial class LP_Message
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LP_Message));
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.MessageBox = new System.Windows.Forms.TextBox();
            this.LeftButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.RightButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.MiddleButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dontAskCheckBox = new MaterialSkin.Controls.MaterialCheckBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Location = new System.Drawing.Point(0, 356);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(1052, 50);
            this.progressBar1.TabIndex = 0;
            // 
            // MessageBox
            // 
            this.MessageBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.MessageBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MessageBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.MessageBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.MessageBox.Location = new System.Drawing.Point(0, 0);
            this.MessageBox.Margin = new System.Windows.Forms.Padding(8);
            this.MessageBox.Multiline = true;
            this.MessageBox.Name = "MessageBox";
            this.MessageBox.Size = new System.Drawing.Size(1052, 268);
            this.MessageBox.TabIndex = 13;
            this.MessageBox.Text = "Checking that everything is fine...";
            this.MessageBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MessageBox.Enter += new System.EventHandler(this.StatusTxt_Enter);
            // 
            // LeftButton
            // 
            this.LeftButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.LeftButton.Depth = 0;
            this.LeftButton.Dock = System.Windows.Forms.DockStyle.Left;
            this.LeftButton.Location = new System.Drawing.Point(0, 0);
            this.LeftButton.Margin = new System.Windows.Forms.Padding(6);
            this.LeftButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.LeftButton.Name = "LeftButton";
            this.LeftButton.Primary = true;
            this.LeftButton.Size = new System.Drawing.Size(284, 88);
            this.LeftButton.TabIndex = 43;
            this.LeftButton.Text = "Yes";
            this.LeftButton.UseVisualStyleBackColor = false;
            this.LeftButton.Visible = false;
            this.LeftButton.Click += new System.EventHandler(this.LeftButton_Click);
            // 
            // RightButton
            // 
            this.RightButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.RightButton.Depth = 0;
            this.RightButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.RightButton.Location = new System.Drawing.Point(768, 0);
            this.RightButton.Margin = new System.Windows.Forms.Padding(6);
            this.RightButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.RightButton.Name = "RightButton";
            this.RightButton.Primary = true;
            this.RightButton.Size = new System.Drawing.Size(284, 88);
            this.RightButton.TabIndex = 44;
            this.RightButton.Text = "No";
            this.RightButton.UseVisualStyleBackColor = false;
            this.RightButton.Visible = false;
            this.RightButton.Click += new System.EventHandler(this.RightButton_Click);
            // 
            // MiddleButton
            // 
            this.MiddleButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.MiddleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.MiddleButton.Depth = 0;
            this.MiddleButton.Location = new System.Drawing.Point(361, 0);
            this.MiddleButton.Margin = new System.Windows.Forms.Padding(6);
            this.MiddleButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.MiddleButton.Name = "MiddleButton";
            this.MiddleButton.Primary = true;
            this.MiddleButton.Size = new System.Drawing.Size(330, 88);
            this.MiddleButton.TabIndex = 45;
            this.MiddleButton.Text = "Retry";
            this.MiddleButton.UseVisualStyleBackColor = false;
            this.MiddleButton.Visible = false;
            this.MiddleButton.Click += new System.EventHandler(this.MiddleButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.MiddleButton);
            this.panel1.Controls.Add(this.RightButton);
            this.panel1.Controls.Add(this.LeftButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 268);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1052, 88);
            this.panel1.TabIndex = 14;
            // 
            // dontAskCheckBox
            // 
            this.dontAskCheckBox.AutoSize = true;
            this.dontAskCheckBox.Depth = 0;
            this.dontAskCheckBox.Font = new System.Drawing.Font("Roboto", 10F);
            this.dontAskCheckBox.Location = new System.Drawing.Point(714, 214);
            this.dontAskCheckBox.Margin = new System.Windows.Forms.Padding(0);
            this.dontAskCheckBox.MouseLocation = new System.Drawing.Point(-1, -1);
            this.dontAskCheckBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.dontAskCheckBox.Name = "dontAskCheckBox";
            this.dontAskCheckBox.Ripple = true;
            this.dontAskCheckBox.Size = new System.Drawing.Size(329, 30);
            this.dontAskCheckBox.TabIndex = 15;
            this.dontAskCheckBox.Text = "Don\'t ask next time";
            this.dontAskCheckBox.UseVisualStyleBackColor = true;
            // 
            // LP_Message
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1052, 406);
            this.Controls.Add(this.dontAskCheckBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MessageBox);
            this.Controls.Add(this.progressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "LP_Message";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LP Updater";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.TextBox MessageBox;
        private MaterialSkin.Controls.MaterialRaisedButton LeftButton;
        private MaterialSkin.Controls.MaterialRaisedButton RightButton;
        private MaterialSkin.Controls.MaterialRaisedButton MiddleButton;
        private System.Windows.Forms.Panel panel1;
        private MaterialSkin.Controls.MaterialCheckBox dontAskCheckBox;
    }
}