﻿namespace LibertyMinerGUI
{
    partial class frmFirstTime
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startupPanel = new System.Windows.Forms.Panel();
            this.startupTitle = new System.Windows.Forms.Label();
            this.applyButton = new MaterialSkin.Controls.MaterialRaisedButton();
            this.errorWarningLbl = new System.Windows.Forms.Label();
            this.walletPanel = new System.Windows.Forms.Panel();
            this.walletTxt = new System.Windows.Forms.TextBox();
            this.walletTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.startupPanel.SuspendLayout();
            this.walletPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // startupPanel
            // 
            this.startupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.startupPanel.Controls.Add(this.startupTitle);
            this.startupPanel.Location = new System.Drawing.Point(17, 17);
            this.startupPanel.Margin = new System.Windows.Forms.Padding(8);
            this.startupPanel.Name = "startupPanel";
            this.startupPanel.Size = new System.Drawing.Size(1911, 187);
            this.startupPanel.TabIndex = 38;
            // 
            // startupTitle
            // 
            this.startupTitle.AutoSize = true;
            this.startupTitle.BackColor = System.Drawing.Color.Transparent;
            this.startupTitle.Font = new System.Drawing.Font("Nirmala UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startupTitle.ForeColor = System.Drawing.Color.White;
            this.startupTitle.Location = new System.Drawing.Point(18, 17);
            this.startupTitle.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.startupTitle.Name = "startupTitle";
            this.startupTitle.Size = new System.Drawing.Size(936, 133);
            this.startupTitle.TabIndex = 0;
            this.startupTitle.Text = "Welcome to LP GUI!";
            // 
            // applyButton
            // 
            this.applyButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.applyButton.Depth = 0;
            this.applyButton.Location = new System.Drawing.Point(1576, 1080);
            this.applyButton.Margin = new System.Windows.Forms.Padding(6);
            this.applyButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.applyButton.Name = "applyButton";
            this.applyButton.Primary = true;
            this.applyButton.Size = new System.Drawing.Size(352, 74);
            this.applyButton.TabIndex = 39;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = false;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // errorWarningLbl
            // 
            this.errorWarningLbl.AutoSize = true;
            this.errorWarningLbl.BackColor = System.Drawing.Color.Transparent;
            this.errorWarningLbl.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorWarningLbl.ForeColor = System.Drawing.Color.Red;
            this.errorWarningLbl.Location = new System.Drawing.Point(34, 1103);
            this.errorWarningLbl.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.errorWarningLbl.Name = "errorWarningLbl";
            this.errorWarningLbl.Size = new System.Drawing.Size(369, 65);
            this.errorWarningLbl.TabIndex = 13;
            this.errorWarningLbl.Text = "Wallet not valid!";
            this.errorWarningLbl.Visible = false;
            // 
            // walletPanel
            // 
            this.walletPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.walletPanel.Controls.Add(this.walletTxt);
            this.walletPanel.Controls.Add(this.walletTitle);
            this.walletPanel.Location = new System.Drawing.Point(17, 773);
            this.walletPanel.Margin = new System.Windows.Forms.Padding(8);
            this.walletPanel.Name = "walletPanel";
            this.walletPanel.Size = new System.Drawing.Size(1902, 199);
            this.walletPanel.TabIndex = 40;
            // 
            // walletTxt
            // 
            this.walletTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(79)))), ((int)(((byte)(99)))));
            this.walletTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.walletTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.walletTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.walletTxt.Location = new System.Drawing.Point(19, 113);
            this.walletTxt.Margin = new System.Windows.Forms.Padding(8);
            this.walletTxt.Multiline = true;
            this.walletTxt.Name = "walletTxt";
            this.walletTxt.Size = new System.Drawing.Size(1848, 60);
            this.walletTxt.TabIndex = 12;
            this.walletTxt.Text = " Input your wallet address here...";
            // 
            // walletTitle
            // 
            this.walletTitle.AutoSize = true;
            this.walletTitle.BackColor = System.Drawing.Color.Transparent;
            this.walletTitle.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.walletTitle.ForeColor = System.Drawing.Color.White;
            this.walletTitle.Location = new System.Drawing.Point(8, 22);
            this.walletTitle.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.walletTitle.Name = "walletTitle";
            this.walletTitle.Size = new System.Drawing.Size(1101, 65);
            this.walletTitle.TabIndex = 0;
            this.walletTitle.Text = "The first thing to do is to input your wallet address:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LibertyMinerGUI.Properties.Resources.youre_welcome;
            this.pictureBox1.Location = new System.Drawing.Point(1030, 236);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(880, 486);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LibertyMinerGUI.Properties.Resources.mining_farms;
            this.pictureBox2.Location = new System.Drawing.Point(58, 236);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(880, 486);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 42;
            this.pictureBox2.TabStop = false;
            // 
            // frmFirstTime
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1954, 1190);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.walletPanel);
            this.Controls.Add(this.errorWarningLbl);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.startupPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "frmFirstTime";
            this.Text = "frmSettings";
            this.startupPanel.ResumeLayout(false);
            this.startupPanel.PerformLayout();
            this.walletPanel.ResumeLayout(false);
            this.walletPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel startupPanel;
        private System.Windows.Forms.Label startupTitle;
        private MaterialSkin.Controls.MaterialRaisedButton applyButton;
        private System.Windows.Forms.Label errorWarningLbl;
        private System.Windows.Forms.Panel walletPanel;
        private System.Windows.Forms.TextBox walletTxt;
        private System.Windows.Forms.Label walletTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}