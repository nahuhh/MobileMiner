﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibertyMinerGUI
{
    public partial class LP_Message : Form
    {
        int Decision;
        bool DontAskNextTime;
        #region Variables
        Properties.Settings settings = new Properties.Settings();
        string xmrigZIPpath = Path.Combine(Application.StartupPath, "xmrig.zip");
        string updateZIPpath = Path.Combine(Application.StartupPath, "update.zip");
        string resolutionExecpath = Path.Combine(Application.StartupPath, "GetScreenResolution.exe");
        #endregion
        public LP_Message(string message, string leftButton, string middleButton, string rightButton,  ref int decision, ref bool AskNextTime)
        {
            InitializeComponent();
            //
            MessageBox.Text = message;
            if(leftButton != null)
            {
                LeftButton.Visible = true;
                LeftButton.Text = leftButton;
            }
            if (middleButton != null)
            {
                MiddleButton.Visible = true;
                MiddleButton.Text = middleButton;
            }
            if (rightButton != null)
            {
                RightButton.Visible = true;
                RightButton.Text = rightButton;
            }
            decision = Decision;
            AskNextTime = !DontAskNextTime;
        }
        #region Buttons
        private void LeftButton_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 100;
            if(dontAskCheckBox.Checked) DontAskNextTime = true;
            Decision = 1;
            Close();
        }

        private void MiddleButton_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 100;
            if(dontAskCheckBox.Checked) DontAskNextTime = true;
            Decision = 2;
            Close();
        }

        private void RightButton_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 100;
            if(dontAskCheckBox.Checked) DontAskNextTime = true;
            Decision = 3;
            Close();
        }
        #endregion
        #region UI
        private void StatusTxt_Enter(object sender, EventArgs e)
        {
            ActiveControl = progressBar1;
        }
        #endregion

 
    }
}
