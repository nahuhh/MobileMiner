﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibertyMinerGUI;

namespace LibertyMinerGUI
{
    public partial class frmFirstTime : Form
    {
        public frmFirstTime()
        {
            InitializeComponent();
        }
        private async void applyButton_Click(object sender, EventArgs e)
        {
            if (LP_Tools.IsWalletValid(walletTxt.Text))
            {
                LP_Tools.SaveWallet(walletTxt.Text);
                LP_Data.form1.GoToWalletPanel();
            }
            else 
            {
                errorWarningLbl.Visible=true;
            }
        }
    }
}
